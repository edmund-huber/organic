from distutils.core import setup

setup(
    name='organic',
    version='0.0.3',
    author='Edmund Huber',
    author_email='edmund.pgh@gmail.com',
    packages=['organic'],
    url='http://pypi.python.org/pypi/organic/',
    description='simple, natural routing'
)
