OK = '200 OK'
NOT_FOUND = '404 Not Found'
SERVER_ERROR = '500 Internal Server Error'
